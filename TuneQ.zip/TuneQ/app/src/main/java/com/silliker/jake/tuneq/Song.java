package com.silliker.jake.tuneq;

import java.io.Serializable;

/**
 * Created by jake on 24/03/16.
 * POJO to represent a song request
 */
public class Song implements Serializable{

    private String artist;
    private String track;
    private String id;

    public Song(){}

    public Song(String artistIn, String trackIn, String idIn){
        this.artist = artistIn;
        this.track = trackIn;
        this.id = idIn;
    }

    public String getTrack() { return track; }

    public String getArtist() {
        return artist;
    }

    public String getId() { return id; }
}
