package com.silliker.jake.tuneq;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.firebase.client.Firebase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import javax.json.Json;
import javax.json.stream.JsonParser;

public class GuestActivity extends AppCompatActivity {

    Firebase firebaseRef;

    final String requestURL = "https://api.spotify.com/v1/search?q=";

    //this hostName will come from the QR scan
    private String hostName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);

        //retrieve the hostname
        hostName = getIntent().getExtras().getString("hostname");

        //needed this to be able to return JSON from spotify
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //initialize firebase
        Firebase.setAndroidContext(this);
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/");

        //add the playlist fragment programmatically
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlaylistFragment playlistFragment = new PlaylistFragment();

        // pass the host id to PlaylistFragment in a Bundle
        Bundle b = new Bundle();
        b.putString("hostname", hostName);
        playlistFragment.setArguments(b);

        fragmentTransaction.add(R.id.activity_guest, playlistFragment);
        fragmentTransaction.commit();

        // wire up the 'request song' fab
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RequestPopupActivity.class);
                startActivityForResult(intent, 1);
            }
        });

    }

    // this catches the song request from RequestPopupActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("Caught the intent");

        //normal request code = 1, result code = -1
        //abnormal result code = 0

        if (resultCode != 0) {
            Bundle b = data.getExtras();

            String artist = b.get("artist").toString().trim();
            String track = b.get("track").toString().trim();
            String trackId = (fetchTrackId(artist, track));
            System.out.println(trackId);
            if (trackId == null){
                Toast t = Toast.makeText(getApplicationContext(), "Error finding " + track + " by " + artist + ", please try a different track.", Toast.LENGTH_SHORT);
                t.show();
                //requestURL = "https://api.spotify.com/v1/search?q=artist:";
            } else {
                Song request = new Song(artist, track, trackId);

                firebaseRef.child("hosts").child(hostName).push().setValue(request);

                Toast t = Toast.makeText(getApplicationContext(), "Requesting.. " + track + " by " + artist, Toast.LENGTH_SHORT);
                t.show();
            }

        }
    }

    //method will fetch the track id (eg "5FZxsHWIvUsmSK1IAvm2pp") for the request using spotify's web api
    //seemingly the best format for the request: https://api.spotify.com/v1/search?q=artist:"foo fighters"track:"arlandria"&type=track
    protected String fetchTrackId(String artist, String track) {

        String trackId;
        String request = requestURL + "artist:" + "%22" + artist.replace(" ","%20") + "%22" + "track:" + "%22" + track.replace(" ", "%20") + "%22"  + "&type=track";

        HttpURLConnection connection = null;
        InputStream inputStream = null;
        BufferedReader br = null;
        StringBuffer sb = new StringBuffer();

        try {
            connection = (HttpURLConnection) new URL(request)
                    .openConnection();
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        try {
            inputStream = connection.getInputStream();
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        // Convert the InputStream to String
        try {
            br = new BufferedReader(new InputStreamReader(inputStream));
            String temp;
            while ((temp = br.readLine()) != null) {
                sb.append(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //cleanup
        try {
            connection.disconnect();
            inputStream.close();
            br.close();
        }
        catch(IOException e){}

        trackId = processJSON(sb);

        return trackId;
    }


    private String processJSON(StringBuffer sb) {

        String jsonString = sb.toString();
        JsonParser parser = Json.createParser(new StringReader(jsonString));
        //  boolean artistTrigger = false;
        String URI;

        System.out.println("ProcessJSON entered");
        // Finally, parse resultant JSON
        try {
            while (parser.hasNext()) {
                JsonParser.Event event = parser.next();
                switch (event) {
                    case VALUE_STRING:
                        if (parser.getString().startsWith("spotify:track:")) {
                            URI = parser.getString();
                            System.out.println(URI);
                            return URI;
                        }
                        break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        //no track URI found
        return null;
    }
}
