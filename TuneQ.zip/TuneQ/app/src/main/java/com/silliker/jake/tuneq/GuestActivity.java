package com.silliker.jake.tuneq;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.firebase.client.Firebase;

import java.util.HashMap;

public class GuestActivity extends AppCompatActivity {

    Firebase firebaseRef;

    //this hostName will come from the QR scan
    private String hostName = "111";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);

        //initialize firebase
        Firebase.setAndroidContext(this);
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/");

        //add the playlist fragment programmatically
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlaylistFragment playlistFragment = new PlaylistFragment();

        // pass the host id to PlaylistFragment in a Bundle
        Bundle b = new Bundle();
        b.putString("hostname", hostName);
        playlistFragment.setArguments(b);

        fragmentTransaction.add(R.id.activity_guest, playlistFragment);
        fragmentTransaction.commit();

        // wire up the 'request song' fab
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RequestPopupActivity.class);
                startActivityForResult(intent, 1);
            }
        });

    }

    // this catches the song request from RequestPopupActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("Caught the intent");

        //normal request code = 1, result code = -1
        //abnormal result code = 0

        if(resultCode != 0) {

            Bundle b = data.getExtras();

            String artist = b.get("artist").toString().trim();
            String track = b.get("track").toString().trim();
            String trackId = (fetchTrackId(artist, track));


            Song request = new Song(artist, track, trackId);

            firebaseRef.child("hosts").child(hostName).push().setValue(request);

            Toast t = Toast.makeText(getApplicationContext(), "Requesting.. " + track + " by " + artist, Toast.LENGTH_SHORT);
            t.show();

        }
    }

    //TODO: this method will fetch the track id (eg "5FZxsHWIvUsmSK1IAvm2pp") for the request using spotify's web api
    //seemingly the best format for the request: https://api.spotify.com/v1/search?q=artist:"foo fighters"track:"arlandria"&type=track
    protected String fetchTrackId(String artist, String track){
        return null;
    }
}
