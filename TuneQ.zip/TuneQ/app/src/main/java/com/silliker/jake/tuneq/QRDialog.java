package com.silliker.jake.tuneq;

import android.app.Activity;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class QRDialog extends Activity {

    private ImageView mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_qrdialog);

        mDialog = (ImageView)findViewById(R.id.your_image);
        mDialog.setClickable(true);

        Bitmap bitmap = new ImageSaver(getApplicationContext()).
                setFileName("qr.png").
                setDirectoryName("images").
                load();

        mDialog.setImageBitmap(bitmap);

        //finish the activity (dismiss the image dialog) if the user clicks
        //anywhere on the image
        mDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}

