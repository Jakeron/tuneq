package com.silliker.jake.tuneq;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;

public class HostActivity extends AppCompatActivity {

    Firebase firebaseRef;
    final String serialno = "111";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host);
    }

    public void setupFirebase(){

        Firebase.setAndroidContext(this);
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/hosts/" + serialno);

        // Add a listener to get called everytime there are changes to the instance of serialno
        firebaseRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                // Delegate these new children to the playlist manager
                System.out.println(dataSnapshot.getKey());
                System.out.println(dataSnapshot.getValue());
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }
}
