package com.silliker.jake.tuneq;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.spotify.sdk.android.authentication.AuthenticationClient;
import com.spotify.sdk.android.authentication.AuthenticationRequest;
import com.spotify.sdk.android.authentication.AuthenticationResponse;
import com.spotify.sdk.android.player.Config;
import com.spotify.sdk.android.player.ConnectionStateCallback;
import com.spotify.sdk.android.player.Player;
import com.spotify.sdk.android.player.PlayerNotificationCallback;
import com.spotify.sdk.android.player.PlayerState;
import com.spotify.sdk.android.player.Spotify;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.NoSuchElementException;

public class HostActivity extends AppCompatActivity implements PlayerNotificationCallback, ConnectionStateCallback {

    //some sample tracks
/*  mQueue.add("5FZxsHWIvUsmSK1IAvm2pp");
    mQueue.add("0ENSn4fwAbCGeFGVUbXEU3");
    mQueue.add("42GP0xKtkolBnmqQRvSllO");*/

    final String TAG = "HostActivity";

    Firebase firebaseRef;

    //the unique id that will serve as the root directory for this host's playlist in firebase
    String hostName;

    //spotify auth
    private static final String CLIENT_ID = "44912193489c4cf69f6dd03c8496e84b";
    private static final String REDIRECT_URI = "tuneq2://callback";
    private static final int REQUEST_CODE = 1337;
    private static final String TRACK_PREFIX = "spotify:track:";

    private Player mPlayer;
    //private LinkedList<Song> mQueue;

    //queue as a hash map ID -> Song.java
    private LinkedHashMap<String, Song> mQueue;

    //private boolean isPlaying;
    // 0 = hasn't been initialized. 1 = playing. -1 = not playing.
    private int isPlaying;
    private ImageButton btn_Play;

    private TextView nowPlayingArtist;
    private TextView nowPlayingTrack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host);

        //get the hostname (serial no of this device)
        hostName = Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);

        nowPlayingArtist = (TextView) findViewById(R.id.txt_now_playing_artist);
        nowPlayingTrack = (TextView) findViewById(R.id.txt_now_playing_track);

        //generate the qr
        generateQR();

        //configure FAB that displays the QR
        FloatingActionButton fabQR = (FloatingActionButton) findViewById(R.id.fab_qr);
        fabQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), QRDialog.class);
                startActivity(intent);
            }
        });

        //configure play/pause button
        isPlaying = 0;
        btn_Play = (ImageButton) findViewById(R.id.btn_play);
        //btn_Play.setClickable(false);
        btn_Play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("CLICK");
                switch (isPlaying) {
                    case 0:
                        try {
                            advancePlaylist();
                            isPlaying = 1;
                            btn_Play.setImageResource(R.drawable.ic_media_pause);
                        } catch (Exception e) {
                            Toast t = Toast.makeText(getApplicationContext(), "Looks like your playlist is empty!", Toast.LENGTH_LONG);
                            t.show();
                        }
                        break;
                    case 1:
                        mPlayer.pause();
                        btn_Play.setImageResource(R.drawable.ic_media_play);
                        isPlaying = -1;
                        break;
                    case -1:
                        mPlayer.resume();
                        btn_Play.setImageResource(R.drawable.ic_media_pause);
                        isPlaying = 1;
                        break;
                }
            }
        });


        // sync firebase
        Firebase.setAndroidContext(this);

        //add the playlist fragment programmatically
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlaylistFragment playlistFragment = new PlaylistFragment();

        // pass the host id to PlaylistFragment in a Bundle
        Bundle b = new Bundle();
        b.putString("hostname", hostName);
        playlistFragment.setArguments(b);

        // load the fragment
        fragmentTransaction.add(R.id.container_playlist_fragment, playlistFragment);
        fragmentTransaction.commit();

        //login to spotify
        authenticate();

        //initialize the queue
        //mQueue = new LinkedList<>();
        mQueue = new LinkedHashMap<>();
        setupFirebase();

    }

    // initializes spotify authentication
    protected void authenticate(){
        AuthenticationRequest.Builder builder = new AuthenticationRequest.Builder(CLIENT_ID,
                AuthenticationResponse.Type.TOKEN,
                REDIRECT_URI);
        builder.setScopes(new String[]{"user-read-private", "streaming"});
        AuthenticationRequest request = builder.build();

        AuthenticationClient.openLoginActivity(this, REQUEST_CODE, request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        // Check if result comes from the correct activity
        if (requestCode == REQUEST_CODE) {
            AuthenticationResponse response = AuthenticationClient.getResponse(resultCode, intent);
            if (response.getType() == AuthenticationResponse.Type.TOKEN) {
                Config playerConfig = new Config(this, response.getAccessToken(), CLIENT_ID);
                Spotify.getPlayer(playerConfig, this, new Player.InitializationObserver() {
                    @Override
                    public void onInitialized(Player player) {
                        mPlayer = player;
                        mPlayer.addConnectionStateCallback(HostActivity.this);
                        mPlayer.addPlayerNotificationCallback(HostActivity.this);
                        //mPlayer.play("spotify:track:2TpxZ7JUBn3uw46aR7qd6V");
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        Log.e("MainActivity", "Could not initialize player: " + throwable.getMessage());
                        //error message here. possibly not
                    }
                });
            }
        }
    }

    public void setupFirebase(){
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/hosts/" + hostName);
        firebaseRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Song song = dataSnapshot.getValue(Song.class);
                //System.out.println(dataSnapshot.getKey());
                //mQueue.addLast(song);
                mQueue.put(dataSnapshot.getKey(), song);

                //safe to enable play button since data is present
                if(!btn_Play.isClickable())
                    btn_Play.setClickable(true);

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }

        });
    }

    // Necessary Overrides
    @Override
    public void onLoggedIn() {
        Log.d("MainActivity", "User logged in");
    }

    @Override
    public void onLoggedOut() {
        Log.d("MainActivity", "User logged out");
    }

    @Override
    public void onLoginFailed(Throwable error) {
        Log.d("MainActivity", error.getMessage().toString());
        Log.d("MainActivity", "Login failed");
    }

    @Override
    public void onTemporaryError() {
        Log.d("MainActivity", "Temporary error occurred");
    }

    @Override
    public void onConnectionMessage(String message) {
        Log.d("MainActivity", "Received connection message: " + message);
    }

    @Override
    public void onPlaybackEvent(EventType eventType, PlayerState playerState) {
        Log.d("MainActivity", "Playback event received: " + eventType.name());

        //switching tracks
        if(eventType.equals(EventType.TRACK_CHANGED)){
            Log.d(TAG, "Track End");
            //play the next song!
            if(!playerState.playing) {
                try{
                    advancePlaylist();
                }
                catch (Exception e){
                    //queue is empty
                    Toast t = Toast.makeText(this, "Looks like your playlist is empty!", Toast.LENGTH_LONG);
                    t.show();
                    isPlaying = 0;
                }
            }
        }

    }

    //plays the song at the front of the queue, updates nowplaying and removes this song from the queue/firebase
    public void advancePlaylist() throws NoSuchElementException{
        //pop off the first entry in the hashmap, concurrently remove it from firebase via Key
        Iterator<String> iterator = mQueue.keySet().iterator();
        String key = iterator.next();  //song to be removed

        mPlayer.play(mQueue.get(key).getId());

        //update "now playing"
        nowPlayingArtist.setText(mQueue.get(key).getArtist());
        nowPlayingTrack.setText(mQueue.get(key).getTrack());

        mQueue.remove(key);
        firebaseRef.child(key).removeValue();

        isPlaying = 1;
    }

    // removes a song from the playlist on long touch
    public void deleteFromPlaylist(){

    }

    public void generateQR(){

        QRCodeWriter writer = new QRCodeWriter();

        try{
            BitMatrix bitMatrix = writer.encode(hostName, BarcodeFormat.QR_CODE, 512, 512);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bmp.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            new ImageSaver(getApplicationContext()).
                    setFileName("qr.png").
                    setDirectoryName("images").
                    save(bmp);

        } catch(WriterException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPlaybackError(ErrorType errorType, String errorDetails) {
        Log.d("MainActivity", "Playback error received: " + errorType.name());
    }

    @Override
    protected void onDestroy() {
        Spotify.destroyPlayer(this);
        super.onDestroy();
    }


}
