package com.silliker.jake.tuneq;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HostActivity extends AppCompatActivity {

    Firebase firebaseRef;

    //the unique id that will serve as the root directory for this host's playlist in firebase
    final String hostName = "111";
    public List<Song> mPlaylist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host);

        Firebase.setAndroidContext(this);
        firebaseRef = new Firebase("https://sizzling-inferno-1580.firebaseio.com/hosts/" + hostName);

        //add the playlist fragment programmatically
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        PlaylistFragment playlistFragment = new PlaylistFragment();

        // pass the host id to PlaylistFragment in a Bundle
        Bundle b = new Bundle();
        b.putString("hostname", hostName);
        playlistFragment.setArguments(b);

        fragmentTransaction.add(R.id.activity_host, playlistFragment);
        fragmentTransaction.commit();

    }


    // grabs all the songs sitting in the firebase under this host
    public void fetchPlaylist(){

        final ArrayList<Song> loadedSongs = new ArrayList<>();

        firebaseRef.addListenerForSingleValueEvent(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot singleRequestSnapshot : dataSnapshot.getChildren()){
                    Song song = singleRequestSnapshot.getValue(Song.class);
                    loadedSongs.add(song);
                    updatePlaylist(loadedSongs);
                    //addToPlaylist(song);
                }

            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
            //i nitialize the fragment only after all of the songs have been loaded

        });
    }

    public void addToPlaylist(Song s){
        System.out.println("Added " + s.getTrack() + " by " + s.getArtist() + " to the local playlist");
        mPlaylist.add(s);
    }

    public void updatePlaylist(List<Song> playlistIn){
        System.out.println("Update Playlist Called");
        mPlaylist = playlistIn;
    }
}
