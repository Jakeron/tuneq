package com.silliker.jake.firebase;

/**
 * Created by jake on 12/03/16.
 * POJO to represent song as Json
 */
public class Song {

    String artist;
    String title;
    String id;

    public Song(String artist, String title, String id){
        this.artist = artist;
        this.title = title;
        this.id = id;
    }

    public Song(){}

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
